

## Workflow

### Deploy
```
sls deploy
```

The console will then show endpoints in the Service Information section.

## credentials

https://serverless.com/framework/docs/providers/aws/guide/credentials/

*View and copy the API Key & Secret to a temporary place. You'll need it in the next step.*

However, there is nothing that says API key or secret on that page.

Based on [this](https://serverless.com/blog/serverless-express-rest-api/) article.
